#!bin/bash

grep No catalunya_setmanal.csv | wc -l
