#!/bin/sh

## Script for practical 2


